# @fomo/rentman-core

One copy of the rules every FOMO tool that talks to Rentman must share:

- `rentman-guard`: the Rentman call guard. One token, one shared quota, one circuit (engineering rule 4). Every Rentman call goes through `rentmanGet` / `rentmanPost` / `rentmanPut`. Vendored from `fomo-bookings-board-v2/lib/rentman-guard.ts` (15 Sep 2026) with the website-sync deviations noted in the file; the board still has its own copy (merging it here is separate, later work).
- `config` + `config/*.json`: categories (folder ids) and spec fields (custom fields, enum ids). `loadConfig()` reads this package's `config/` unless `CONFIG_DIR` is set.
- `classify`: the folder walk and catalogue rules the website sync publishes by.
- `rentman-types`: catalogue row types and `buildFolderPaths`.
- `custom-fields`: `wipedKeys`, the check that a PUT did not blank custom fields it did not send.
- `goods-in`: which units need a QR sticker and checking a scanned sticker (kit onboarding phase 3).
- `match`, `proposal-check`, `segment`: kit-onboarding build-board rules (shortlisting existing records, checking a proposal, split-off demo batches), shared by the onboarding job and the inventory dashboard.

Moved out of `fomo-rentals-website-rebuild/sync` on 6 Oct 2026 (that repo's history, up to 76bed6e, has the earlier changes). Used by the website sync and `fomo-kit-onboarding`.

## Use

Each user repo commits the packed package and installs it from there, so no build needs a GitHub login (Jamie, 6 Oct 2026):

```
npm pack --pack-destination ../<user repo>/vendor        # here, after tagging
npm install ./vendor/fomo-rentman-core-<version>.tgz     # in the user repo; delete the old tgz
```

Users: `fomo-kit-onboarding` (`vendor/`), `fomo-rentals-website-rebuild` (`sync/vendor/`).

```ts
import { rentmanGet } from "@fomo/rentman-core/rentman-guard";
```

`dist/` is built and committed (Node will not strip types inside `node_modules`, and npm may not run install scripts of git dependencies). After editing `src/`, run `npm run build` and commit `dist/` with it; `npm run check-dist` fails if they differ. Credentials: Application Default Credentials for the board's Firestore (`fomo-bookings-board-v2`, `datastore.user`), and `RENTMAN_API_TOKEN` in the environment. Never commit secrets.

## Changing a rule

Edit here, `npm test && npm run lint`, tag a new version, then bump each user's dependency. Engineering rules: `../FOMO-ENGINEERING-RULES.md`.
